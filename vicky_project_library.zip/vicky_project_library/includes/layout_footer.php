  </main>
</div>
<script src="<?= e(url('assets/js/app.js')) ?>"></script>
</body>
</html>
