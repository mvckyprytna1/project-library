<?php
declare(strict_types=1);

require __DIR__ . '/config/app.php';
require __DIR__ . '/config/database.php';
require __DIR__ . '/includes/helpers.php';
require __DIR__ . '/includes/csrf.php';
require __DIR__ . '/includes/auth.php';

$pdo = db();

function run_install_sql(PDO $pdo): void
{
    $sqlFile = __DIR__ . '/database.sql';

    if (!is_file($sqlFile)) {
        return;
    }

    $sql = file_get_contents($sqlFile);
    $sql = preg_replace('/^\s*--.*$/m', '', (string)$sql);
    $statements = array_filter(array_map('trim', explode(';', $sql)));

    foreach ($statements as $statement) {
        if ($statement !== '') {
            $pdo->exec($statement);
        }
    }
}

try {
    run_install_sql($pdo);
} catch (Throwable $e) {
    $installError = 'Gagal membuat tabel otomatis. Import database.sql lewat phpMyAdmin lalu refresh halaman ini.';
}

$count = 0;

try {
    $count = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
} catch (Throwable $e) {
    $count = 0;
}

if ($count > 0 && !is_logged_in()) {
    redirect('auth/login.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    if ($count > 0) {
        set_flash('info', 'Owner sudah dibuat. Login saja.');
        redirect('auth/login.php');
    }

    $name = trim((string)($_POST['name'] ?? ''));
    $email = trim((string)($_POST['email'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $confirmPassword = (string)($_POST['confirm_password'] ?? '');

    if ($name === '' || $email === '' || $password === '') {
        $error = 'Nama, email, dan password wajib diisi.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Format email tidak valid.';
    } elseif (strlen($password) < 8) {
        $error = 'Password minimal 8 karakter.';
    } elseif ($password !== $confirmPassword) {
        $error = 'Konfirmasi password tidak sama.';
    } else {
        $stmt = $pdo->prepare('INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)');
        $stmt->execute([
            $name,
            $email,
            password_hash($password, PASSWORD_DEFAULT),
            'owner',
        ]);

        $userId = (int)$pdo->lastInsertId();
        login_user(['id' => $userId]);
        set_flash('success', 'Install selesai. Akun owner berhasil dibuat.');
        redirect('dashboard.php');
    }
}
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Install - <?= e(APP_NAME) ?></title>
  <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
</head>
<body class="auth-page">
  <div class="auth-wrap">
    <form class="card auth-card" method="post">
      <div class="auth-logo">VP</div>
      <p class="eyebrow">First Setup</p>
      <h1>Buat Owner Pertama</h1>
      <p class="help">Installer ini membuat tabel database dan akun owner pertama.</p>

      <?php if (!empty($installError)): ?>
        <div class="alert alert-error"><?= e($installError) ?></div>
      <?php endif; ?>

      <?php if (!empty($error)): ?>
        <div class="alert alert-error"><?= e($error) ?></div>
      <?php endif; ?>

      <?= csrf_field() ?>

      <div class="form-group">
        <label>Nama Owner</label>
        <input class="input" name="name" required value="<?= e($_POST['name'] ?? '') ?>">
      </div>

      <div class="form-group">
        <label>Email</label>
        <input class="input" type="email" name="email" required value="<?= e($_POST['email'] ?? '') ?>">
      </div>

      <div class="form-group">
        <label>Password</label>
        <input class="input" type="password" name="password" minlength="8" required>
      </div>

      <div class="form-group">
        <label>Konfirmasi Password</label>
        <input class="input" type="password" name="confirm_password" minlength="8" required>
      </div>

      <div class="actions">
        <button class="btn full" type="submit">Install Sekarang</button>
      </div>
    </form>
  </div>
</body>
</html>
